﻿namespace Учет_продаж
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage_main = new System.Windows.Forms.TabPage();
            this.splitContainer_main = new System.Windows.Forms.SplitContainer();
            this.groupBox_main_1 = new System.Windows.Forms.GroupBox();
            this.treeView_main = new System.Windows.Forms.TreeView();
            this.groupBox_main_2 = new System.Windows.Forms.GroupBox();
            this.button_main_save_check = new System.Windows.Forms.Button();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_main_delete_check = new System.Windows.Forms.Button();
            this.button_main_print_receipt = new System.Windows.Forms.Button();
            this.button_main_create_new_check = new System.Windows.Forms.Button();
            this.tabPage_log = new System.Windows.Forms.TabPage();
            this.splitContainer_log = new System.Windows.Forms.SplitContainer();
            this.groupBox_log_1 = new System.Windows.Forms.GroupBox();
            this.treeView_log = new System.Windows.Forms.TreeView();
            this.groupBox_log_2 = new System.Windows.Forms.GroupBox();
            this.button_log_delete_check = new System.Windows.Forms.Button();
            this.button_log_print_receipt = new System.Windows.Forms.Button();
            this.dataGridView_log = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl_main.SuspendLayout();
            this.tabPage_main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_main)).BeginInit();
            this.splitContainer_main.Panel1.SuspendLayout();
            this.splitContainer_main.Panel2.SuspendLayout();
            this.splitContainer_main.SuspendLayout();
            this.groupBox_main_1.SuspendLayout();
            this.groupBox_main_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            this.tabPage_log.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_log)).BeginInit();
            this.splitContainer_log.Panel1.SuspendLayout();
            this.splitContainer_log.Panel2.SuspendLayout();
            this.splitContainer_log.SuspendLayout();
            this.groupBox_log_1.SuspendLayout();
            this.groupBox_log_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_log)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl_main
            // 
            this.tabControl_main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl_main.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl_main.Controls.Add(this.tabPage_main);
            this.tabControl_main.Controls.Add(this.tabPage_log);
            this.tabControl_main.Location = new System.Drawing.Point(0, 4);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(533, 267);
            this.tabControl_main.TabIndex = 0;
            this.tabControl_main.SelectedIndexChanged += new System.EventHandler(this.tabControl_main_SelectedIndexChanged);
            // 
            // tabPage_main
            // 
            this.tabPage_main.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage_main.Controls.Add(this.splitContainer_main);
            this.tabPage_main.Location = new System.Drawing.Point(4, 25);
            this.tabPage_main.Name = "tabPage_main";
            this.tabPage_main.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_main.Size = new System.Drawing.Size(525, 238);
            this.tabPage_main.TabIndex = 0;
            this.tabPage_main.Text = "Касса";
            // 
            // splitContainer_main
            // 
            this.splitContainer_main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer_main.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer_main.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_main.Name = "splitContainer_main";
            // 
            // splitContainer_main.Panel1
            // 
            this.splitContainer_main.Panel1.Controls.Add(this.groupBox_main_1);
            // 
            // splitContainer_main.Panel2
            // 
            this.splitContainer_main.Panel2.Controls.Add(this.groupBox_main_2);
            this.splitContainer_main.Size = new System.Drawing.Size(525, 238);
            this.splitContainer_main.SplitterDistance = 131;
            this.splitContainer_main.TabIndex = 1;
            // 
            // groupBox_main_1
            // 
            this.groupBox_main_1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_main_1.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox_main_1.Controls.Add(this.treeView_main);
            this.groupBox_main_1.Location = new System.Drawing.Point(0, 0);
            this.groupBox_main_1.Name = "groupBox_main_1";
            this.groupBox_main_1.Size = new System.Drawing.Size(132, 239);
            this.groupBox_main_1.TabIndex = 2;
            this.groupBox_main_1.TabStop = false;
            this.groupBox_main_1.Text = "Чек";
            // 
            // treeView_main
            // 
            this.treeView_main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView_main.Location = new System.Drawing.Point(6, 19);
            this.treeView_main.Name = "treeView_main";
            this.treeView_main.Size = new System.Drawing.Size(120, 214);
            this.treeView_main.TabIndex = 0;
            this.treeView_main.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_main_AfterSelect);
            // 
            // groupBox_main_2
            // 
            this.groupBox_main_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_main_2.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox_main_2.Controls.Add(this.button_main_save_check);
            this.groupBox_main_2.Controls.Add(this.dataGridView_main);
            this.groupBox_main_2.Controls.Add(this.button_main_delete_check);
            this.groupBox_main_2.Controls.Add(this.button_main_print_receipt);
            this.groupBox_main_2.Controls.Add(this.button_main_create_new_check);
            this.groupBox_main_2.Location = new System.Drawing.Point(0, 0);
            this.groupBox_main_2.Name = "groupBox_main_2";
            this.groupBox_main_2.Size = new System.Drawing.Size(391, 239);
            this.groupBox_main_2.TabIndex = 3;
            this.groupBox_main_2.TabStop = false;
            this.groupBox_main_2.Text = "Касса";
            // 
            // button_main_save_check
            // 
            this.button_main_save_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_main_save_check.BackColor = System.Drawing.SystemColors.Control;
            this.button_main_save_check.Location = new System.Drawing.Point(102, 210);
            this.button_main_save_check.Name = "button_main_save_check";
            this.button_main_save_check.Size = new System.Drawing.Size(90, 23);
            this.button_main_save_check.TabIndex = 17;
            this.button_main_save_check.Text = "Сохранить чек";
            this.button_main_save_check.UseVisualStyleBackColor = false;
            this.button_main_save_check.Click += new System.EventHandler(this.button_main_save_check_Click);
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToOrderColumns = true;
            this.dataGridView_main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_main.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_main.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView_main.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView_main.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.Size = new System.Drawing.Size(378, 185);
            this.dataGridView_main.TabIndex = 12;
            this.dataGridView_main.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dataGridView_main_CellValidating);
            // 
            // Column1
            // 
            this.Column1.FillWeight = 104.9069F;
            this.Column1.HeaderText = "Товар";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.FillWeight = 104.9069F;
            this.Column2.HeaderText = "Цена";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.FillWeight = 104.9069F;
            this.Column3.HeaderText = "Количество";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.FillWeight = 85.27919F;
            this.Column4.HeaderText = "Скидка";
            this.Column4.Name = "Column4";
            // 
            // button_main_delete_check
            // 
            this.button_main_delete_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_main_delete_check.BackColor = System.Drawing.SystemColors.Control;
            this.button_main_delete_check.Enabled = false;
            this.button_main_delete_check.Location = new System.Drawing.Point(198, 210);
            this.button_main_delete_check.Name = "button_main_delete_check";
            this.button_main_delete_check.Size = new System.Drawing.Size(90, 23);
            this.button_main_delete_check.TabIndex = 16;
            this.button_main_delete_check.Text = "Удалить чек";
            this.button_main_delete_check.UseVisualStyleBackColor = false;
            this.button_main_delete_check.Click += new System.EventHandler(this.button_main_delete_check_Click);
            // 
            // button_main_print_receipt
            // 
            this.button_main_print_receipt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_main_print_receipt.BackColor = System.Drawing.SystemColors.Control;
            this.button_main_print_receipt.Enabled = false;
            this.button_main_print_receipt.Location = new System.Drawing.Point(294, 210);
            this.button_main_print_receipt.Name = "button_main_print_receipt";
            this.button_main_print_receipt.Size = new System.Drawing.Size(90, 23);
            this.button_main_print_receipt.TabIndex = 15;
            this.button_main_print_receipt.Text = "Печать";
            this.button_main_print_receipt.UseVisualStyleBackColor = false;
            this.button_main_print_receipt.Click += new System.EventHandler(this.button_main_print_receipt_Click);
            // 
            // button_main_create_new_check
            // 
            this.button_main_create_new_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_main_create_new_check.BackColor = System.Drawing.SystemColors.Control;
            this.button_main_create_new_check.Location = new System.Drawing.Point(6, 210);
            this.button_main_create_new_check.Name = "button_main_create_new_check";
            this.button_main_create_new_check.Size = new System.Drawing.Size(90, 23);
            this.button_main_create_new_check.TabIndex = 14;
            this.button_main_create_new_check.Text = "Новый чек";
            this.button_main_create_new_check.UseVisualStyleBackColor = false;
            this.button_main_create_new_check.Click += new System.EventHandler(this.button_main_create_new_check_Click);
            // 
            // tabPage_log
            // 
            this.tabPage_log.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_log.Controls.Add(this.splitContainer_log);
            this.tabPage_log.Location = new System.Drawing.Point(4, 25);
            this.tabPage_log.Name = "tabPage_log";
            this.tabPage_log.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_log.Size = new System.Drawing.Size(525, 238);
            this.tabPage_log.TabIndex = 1;
            this.tabPage_log.Text = "Журнал";
            // 
            // splitContainer_log
            // 
            this.splitContainer_log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer_log.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_log.Name = "splitContainer_log";
            // 
            // splitContainer_log.Panel1
            // 
            this.splitContainer_log.Panel1.Controls.Add(this.groupBox_log_1);
            // 
            // splitContainer_log.Panel2
            // 
            this.splitContainer_log.Panel2.Controls.Add(this.groupBox_log_2);
            this.splitContainer_log.Size = new System.Drawing.Size(525, 238);
            this.splitContainer_log.SplitterDistance = 131;
            this.splitContainer_log.TabIndex = 0;
            // 
            // groupBox_log_1
            // 
            this.groupBox_log_1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_log_1.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox_log_1.Controls.Add(this.treeView_log);
            this.groupBox_log_1.Location = new System.Drawing.Point(0, 0);
            this.groupBox_log_1.Name = "groupBox_log_1";
            this.groupBox_log_1.Size = new System.Drawing.Size(132, 239);
            this.groupBox_log_1.TabIndex = 2;
            this.groupBox_log_1.TabStop = false;
            this.groupBox_log_1.Text = "Лист";
            // 
            // treeView_log
            // 
            this.treeView_log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView_log.Location = new System.Drawing.Point(6, 19);
            this.treeView_log.Name = "treeView_log";
            this.treeView_log.Size = new System.Drawing.Size(120, 214);
            this.treeView_log.TabIndex = 0;
            this.treeView_log.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_log_AfterSelect);
            // 
            // groupBox_log_2
            // 
            this.groupBox_log_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_log_2.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox_log_2.Controls.Add(this.button_log_delete_check);
            this.groupBox_log_2.Controls.Add(this.button_log_print_receipt);
            this.groupBox_log_2.Controls.Add(this.dataGridView_log);
            this.groupBox_log_2.Location = new System.Drawing.Point(0, 0);
            this.groupBox_log_2.Name = "groupBox_log_2";
            this.groupBox_log_2.Size = new System.Drawing.Size(391, 239);
            this.groupBox_log_2.TabIndex = 3;
            this.groupBox_log_2.TabStop = false;
            this.groupBox_log_2.Text = "Информация";
            // 
            // button_log_delete_check
            // 
            this.button_log_delete_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_log_delete_check.BackColor = System.Drawing.SystemColors.Control;
            this.button_log_delete_check.Enabled = false;
            this.button_log_delete_check.Location = new System.Drawing.Point(6, 210);
            this.button_log_delete_check.Name = "button_log_delete_check";
            this.button_log_delete_check.Size = new System.Drawing.Size(90, 23);
            this.button_log_delete_check.TabIndex = 15;
            this.button_log_delete_check.Text = "Удалить чек";
            this.button_log_delete_check.UseVisualStyleBackColor = false;
            this.button_log_delete_check.Click += new System.EventHandler(this.button_log_delete_check_Click);
            // 
            // button_log_print_receipt
            // 
            this.button_log_print_receipt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_log_print_receipt.BackColor = System.Drawing.SystemColors.Control;
            this.button_log_print_receipt.Enabled = false;
            this.button_log_print_receipt.Location = new System.Drawing.Point(294, 210);
            this.button_log_print_receipt.Name = "button_log_print_receipt";
            this.button_log_print_receipt.Size = new System.Drawing.Size(90, 23);
            this.button_log_print_receipt.TabIndex = 14;
            this.button_log_print_receipt.Text = "Печать";
            this.button_log_print_receipt.UseVisualStyleBackColor = false;
            this.button_log_print_receipt.Click += new System.EventHandler(this.button_log_print_receipt_Click);
            // 
            // dataGridView_log
            // 
            this.dataGridView_log.AllowUserToOrderColumns = true;
            this.dataGridView_log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_log.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_log.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView_log.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_log.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dataGridView_log.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView_log.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_log.Name = "dataGridView_log";
            this.dataGridView_log.Size = new System.Drawing.Size(378, 185);
            this.dataGridView_log.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 104.9069F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Товар";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 104.9069F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 104.9069F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 85.27919F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Скидка";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 272);
            this.Controls.Add(this.tabControl_main);
            this.MinimumSize = new System.Drawing.Size(550, 310);
            this.Name = "FormMain";
            this.Text = "Учет продаж";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage_main.ResumeLayout(false);
            this.splitContainer_main.Panel1.ResumeLayout(false);
            this.splitContainer_main.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_main)).EndInit();
            this.splitContainer_main.ResumeLayout(false);
            this.groupBox_main_1.ResumeLayout(false);
            this.groupBox_main_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            this.tabPage_log.ResumeLayout(false);
            this.splitContainer_log.Panel1.ResumeLayout(false);
            this.splitContainer_log.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_log)).EndInit();
            this.splitContainer_log.ResumeLayout(false);
            this.groupBox_log_1.ResumeLayout(false);
            this.groupBox_log_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_log)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage_log;
        private System.Windows.Forms.SplitContainer splitContainer_log;
        private System.Windows.Forms.GroupBox groupBox_log_1;
        private System.Windows.Forms.GroupBox groupBox_log_2;
        private System.Windows.Forms.TabPage tabPage_main;
        private System.Windows.Forms.SplitContainer splitContainer_main;
        private System.Windows.Forms.GroupBox groupBox_main_1;
        private System.Windows.Forms.TreeView treeView_main;
        private System.Windows.Forms.TreeView treeView_log;
        private System.Windows.Forms.DataGridView dataGridView_log;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button button_log_delete_check;
        private System.Windows.Forms.Button button_log_print_receipt;
        private System.Windows.Forms.GroupBox groupBox_main_2;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Button button_main_delete_check;
        private System.Windows.Forms.Button button_main_print_receipt;
        private System.Windows.Forms.Button button_main_create_new_check;
        private System.Windows.Forms.Button button_main_save_check;
    }
}

