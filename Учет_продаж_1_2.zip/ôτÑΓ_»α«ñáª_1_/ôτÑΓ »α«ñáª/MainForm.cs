﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Учет_продаж
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        // контекстное меню: добавить сроки или удалить
        private void Del_Add_Cell()
        {
            ToolStripMenuItem AddNewRowMenuItem = new ToolStripMenuItem("Добавить строку");
            ToolStripMenuItem DeleteRowMenuItem = new ToolStripMenuItem("Удалить строку");

            ContextMenuStrip contextMenuStrip1 = new ContextMenuStrip();
            contextMenuStrip1.Items.AddRange(new[] { AddNewRowMenuItem, DeleteRowMenuItem });
            dataGridView_main.ContextMenuStrip = contextMenuStrip1;

            AddNewRowMenuItem.Click += (ss, ee) =>
            {
                try
                {
                    dataGridView_main.Rows.Add();
                }
                catch { }
            };
            DeleteRowMenuItem.Click += (ss, ee) =>
            {
                if (this.dataGridView_main.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow item in dataGridView_main.SelectedRows)
                    {
                        try
                        {
                            dataGridView_main.Rows.Remove(item);
                        }
                        catch { }
                    }
                }
            };
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //MessageBox.Show(DateTime.Now.ToString("dd.MM.yyyy"));
            CreateFloder();

            Del_Add_Cell();

            // товар: 0 цена: 1 количество: 2 скидка: 3
            //dataGridView_main.Rows[0].Cells[3].Value = "12346";

            //int rows = 30;
            //dataGridView_main.Rows.Add(rows);
            //for (int i = 0; i < rows; i++)
            //{
            //    dataGridView_main.Rows[i].Cells[0].Value = "test: " + i;
            //    dataGridView_main.Rows[i].Cells[1].Value = i + 1;
            //    dataGridView_main.Rows[i].Cells[2].Value = i + 2;
            //    dataGridView_main.Rows[i].Cells[3].Value = i + 3;
            //}

            // картинки в деревьях
            ImageList ImageList_ = new ImageList();
            ImageList_.ImageSize = new System.Drawing.Size(16, 16);
            ImageList_.Images.Add("0_directory_closed", Image.FromFile("Icons/directory_closed.png"));
            ImageList_.Images.Add("1_directory_open", Image.FromFile("Icons/directory_open.png"));
            ImageList_.Images.Add("2_file", Image.FromFile("Icons/file.png"));
            ImageList_.Images.Add("3_product", Image.FromFile("Icons/product.png"));

            treeView_log.ImageList = ImageList_;
            treeView_main.ImageList = ImageList_;
        }

        // создать католог для чеков
        private void CreateFloder()
        {
            if (!Directory.Exists("Log/" + DateTime.Now.ToString("dd.MM.yyyy")))
            {
                Directory.CreateDirectory("Log/" + DateTime.Now.ToString("dd.MM.yyyy"));
            }
        }

        // загрузка дерева в журнале, активация при нажатии на вкладку "Журналы"
        private void tabControl_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            DrawTreeViewLog("Log/" + DateTime.Now.ToString("dd.MM.yyyy"));
            DrawTreeViewMain();
        }

        // для взаимодействия с чеками
        int IndexFile = 0;
        List<string> FileNames = new List<string>();
        //List<bool> IsSaveFiles = new List<bool>();
        // создать чек
        private void button_main_create_new_check_Click(object sender, EventArgs e)
        {
            CreateFloder();
            dataGridView_main.Rows.Clear();
            FileNames.Add("Log/" + DateTime.Now.ToString("dd.MM.yyyy") + "/" + "Чек от " + DateTime.Now.ToString("HH-mm-ss") + ".txt");
            IndexFile = FileNames.Count - 1;
        }

        // cохранить чек 
        private void button_main_save_check_Click(object sender, EventArgs e)
        {
            try
            {
                CreateFloder();
                if (dataGridView_main.Rows.Count > 1)
                {
                    if (FileNames.Count < 1)
                    {
                        FileNames.Add("Log/" + DateTime.Now.ToString("dd.MM.yyyy") + "/" + "Чек от " + DateTime.Now.ToString("HH-mm-ss") + ".txt");
                        IndexFile = FileNames.Count - 1;
                    }
                    for (int i = 0; i < dataGridView_main.Rows.Count - 1; i++)
                    {
                        if (dataGridView_main.Rows[i].Cells[0].Value == null) dataGridView_main.Rows[i].Cells[0].Value = "Пусто";
                        if (dataGridView_main.Rows[i].Cells[1].Value == null) dataGridView_main.Rows[i].Cells[1].Value = "0";
                        if (dataGridView_main.Rows[i].Cells[2].Value == null) dataGridView_main.Rows[i].Cells[2].Value = "0";
                        if (dataGridView_main.Rows[i].Cells[3].Value == null) dataGridView_main.Rows[i].Cells[3].Value = "0";
                    }

                    string out_ = "";
                    for (int i = 0; i < dataGridView_main.Rows.Count - 1; i++)
                    {
                        out_ +=
                            "" + dataGridView_main.Rows[i].Cells[0].Value.ToString() +
                            "#" + dataGridView_main.Rows[i].Cells[1].Value.ToString() +
                            "§" + dataGridView_main.Rows[i].Cells[2].Value.ToString() +
                            "~" + dataGridView_main.Rows[i].Cells[3].Value.ToString();
                        if (i < dataGridView_main.Rows.Count - 2)
                            out_ += "\n";
                    }
                    File.WriteAllText(FileNames[IndexFile], out_);
                    //TestListFile();
                    DrawTreeViewMain();
                }
                else { MessageBox.Show("Добавьте товары в чек"); }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // проверка на несуществующие файлы - и их удаление из FileNames
        private void TestListFile()
        {
            List<string> list_del = new List<string>();
            foreach (var item in FileNames)
                if (!File.Exists(item))
                    list_del.Add(item);

            foreach (var item in list_del)
                FileNames.Remove(item);

            list_del = null;
        }

        // загрузка данных в дерево чеков
        private void DrawTreeViewMain()
        {
            try
            {
                TestListFile();
                treeView_main.Nodes.Clear();
                try
                {
                    foreach (var item in FileNames)
                    {
                        try
                        {
                            string input = File.ReadAllText(item);
                            string[] input_array = input.Split('\n');

                            TreeNode tovarNode = new TreeNode(Path.GetFileNameWithoutExtension(item).Replace("-", ":"));
                            tovarNode.ImageIndex = 2;
                            tovarNode.SelectedImageIndex = 2;

                            for (int i = 0; i < input_array.Length; i++)
                            {
                                string[] parts = input_array[i].Split(new char[] { '#', '§', '~' });
                                TreeNode tovarNode1_ = new TreeNode("Товар: " + parts[0]) { ImageIndex = 3, SelectedImageIndex = 3 };
                                tovarNode1_.Nodes.Add(new TreeNode("Цена: " + parts[1]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode1_.Nodes.Add(new TreeNode("Количество: " + parts[2]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode1_.Nodes.Add(new TreeNode("Скидка: " + parts[3]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode.Nodes.Add(tovarNode1_);
                            }
                            treeView_main.Nodes.Add(tovarNode);
                        }
                        catch (Exception)
                        {
                            FileNames.Remove(item);
                        }
                    }
                }
                catch (InvalidOperationException)
                {
                    DrawTreeViewMain();
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // загрузка данных в дерево журналов
        private void DrawTreeViewLog(string Expand)
        {
            try
            {
                if (tabControl_main.SelectedIndex == 1)
                {
                    treeView_log.Nodes.Clear();
                    foreach (var item_ in Directory.GetDirectories("Log"))
                    {
                        TreeNode tovarNode = new TreeNode(new DirectoryInfo(item_).Name);

                        if (Expand.Equals(item_.Replace('\\', '/')))
                            tovarNode.Expand();

                        tovarNode.ImageIndex = 0;
                        tovarNode.SelectedImageIndex = 1;

                        foreach (var item in Directory.GetFiles(item_))
                        {
                            TreeNode tovarNode_ = new TreeNode(Path.GetFileNameWithoutExtension(item).Replace('-', ':'));
                            tovarNode_.ImageIndex = 2;
                            tovarNode_.SelectedImageIndex = 2;

                            string input = File.ReadAllText(item);
                            foreach (var item1 in input.Split('\n'))
                            {
                                string[] parts = item1.Split(new char[] { '#', '§', '~' });
                                TreeNode tovarNode1_ = new TreeNode("Товар: " + parts[0]) { ImageIndex = 3, SelectedImageIndex = 3 };
                                tovarNode1_.Nodes.Add(new TreeNode("Цена: " + parts[1]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode1_.Nodes.Add(new TreeNode("Количество: " + parts[2]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode1_.Nodes.Add(new TreeNode("Скидка: " + parts[3]) { ImageIndex = 3, SelectedImageIndex = 3 });
                                tovarNode_.Nodes.Add(tovarNode1_);
                            }
                            tovarNode.Nodes.Add(tovarNode_);
                        }
                        treeView_log.Nodes.Add(tovarNode);
                    }
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // удалить чек для кассы
        private void button_main_delete_check_Click(object sender, EventArgs e)
        {
            try
            {
                TestListFile();
                TreeNode CurrentNode = treeView_main.SelectedNode;
                if (CurrentNode != null)
                {
                    FileNames.RemoveAt(CurrentNode.Index);
                    CurrentNode.Remove();
                    //if (CurrentNode.Index < FileNames.Count)
                    //{
                    //    File.Delete(FileNames[CurrentNode.Index]);
                    //    FileNames.RemoveAt(CurrentNode.Index);
                    //}
                    //button_delete_check.Enabled = false;
                    //button_print_receipt.Enabled = false; 
                }
                else
                {
                    button_main_delete_check.Enabled = false;
                    button_main_print_receipt.Enabled = false;
                    MessageBox.Show("Выберите чек который хотите удалить");
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // удалить чек для журнала
        private void button_log_delete_check_Click(object sender, EventArgs e)
        {
            try
            {
                TreeNode CurrentNode = treeView_log.SelectedNode;
                if (CurrentNode != null)
                {
                    if (CurrentNode.Level == 1)
                    {
                        DialogResult result = MessageBox.Show("Вы действительно хотите безвозвратно удалить чек: \"" + CurrentNode.Text + "\".", "Удалить файл", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            File.Delete("Log/" + CurrentNode.Parent.Text + "/" + CurrentNode.Text.Replace(":", "-") + ".txt");
                            DrawTreeViewLog("Log/" + CurrentNode.Parent.Text);
                        }
                    }

                    if (CurrentNode.Level == 0)
                    {
                        DialogResult result = MessageBox.Show("Вы действительно хотите безвозвратно удалить каталог: \"" + CurrentNode.Text + "\".", "Удалить каталог", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            Directory.Delete("Log/" + CurrentNode.Text);
                            DrawTreeViewLog("Log/" + CurrentNode.Text);
                        }
                    }
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // напечатать чек для кассы
        private void button_main_print_receipt_Click(object sender, EventArgs e)
        {
            TreeNode CurrentNode = treeView_main.SelectedNode;
            if (CurrentNode != null)
            {
                MessageBox.Show("Скоро");
                //button_delete_check.Enabled = false;
                //button_print_receipt.Enabled = false; 
            }
            else
            {
                button_main_delete_check.Enabled = false;
                button_main_print_receipt.Enabled = false;
                MessageBox.Show("Выберите чек который хотите напечатать");
            }
        }

        // напечатать чек для журнала
        private void button_log_print_receipt_Click(object sender, EventArgs e)
        {

            TreeNode CurrentNode = treeView_log.SelectedNode;
            if (CurrentNode != null)
            {
                MessageBox.Show("Скоро");
                //button_delete_check.Enabled = false;
                //button_print_receipt.Enabled = false; 
            }
            else
            {
                button_log_delete_check.Enabled = false;
                button_log_print_receipt.Enabled = false;
                MessageBox.Show("Выберите чек который хотите напечатать");
            }
        }

        /*
        // вспомогательный ввод текста
        int CellX = 0;
        int CellY = 0;
        int CellClick = 0;
        int CellClickMax = 2;
        private void dataGridView_main_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (CellY == e.RowIndex && CellX == e.ColumnIndex)
            {
                if (CellClick > CellClickMax)
                {
                    CellClick = 0;
                    dataGridView_main.EndEdit();
                    //dataGridView_main.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "123";
                    ContextMenuStrip contextMenuStrip1 = new ContextMenuStrip();
                    // создаем элементы меню
                    ToolStripMenuItem copyMenuItem = new ToolStripMenuItem(dataGridView_main.Rows[e.RowIndex].Cells[e.ColumnIndex].Value + ">Копировать");
                    ToolStripMenuItem pasteMenuItem = new ToolStripMenuItem(dataGridView_main.Rows[e.RowIndex].Cells[e.ColumnIndex].Value + ">Вставить");
                    // добавляем элементы в меню
                    contextMenuStrip1.Items.AddRange(new[] { copyMenuItem, pasteMenuItem });
                    contextMenuStrip1.Show(new Point(Cursor.Position.X, Cursor.Position.Y));
                    copyMenuItem.Click += (ss, ee) => dataGridView_main.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = copyMenuItem.Text;
                    pasteMenuItem.Click += (ss, ee) => dataGridView_main.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = copyMenuItem.Text;
                }
                else { CellClick++; }
            }
            else
            {
                CellY = e.RowIndex;
                CellX = e.ColumnIndex;
                CellClick = 1;
            }
        }
         */

        // провека на запрещеные символы в табличе чеков
        private void dataGridView_main_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            //const string disallowed = @"[^0-9A-Za-z-\/]";
            //var newText = Regex.Replace(e.FormattedValue.ToString(), disallowed, string.Empty);
            //dataGridView_main.Rows[e.RowIndex].ErrorText = "";
            //if (dataGridView_main.Rows[e.RowIndex].IsNewRow) return;
            //if (string.CompareOrdinal(e.FormattedValue.ToString(), newText) == 0) return;
            //e.Cancel = true;
            //dataGridView_main.Rows[e.RowIndex].ErrorText = "Некорректный символ!";
            try
            {
                var newText = e.FormattedValue.ToString();
                newText = newText.Replace("#", string.Empty);
                newText = newText.Replace("§", string.Empty);
                newText = newText.Replace("~", string.Empty);
                dataGridView_main.Rows[e.RowIndex].ErrorText = "";
                if (dataGridView_main.Rows[e.RowIndex].IsNewRow) return;
                if (string.CompareOrdinal(e.FormattedValue.ToString(), newText) == 0) return;
                e.Cancel = true;
                dataGridView_main.Rows[e.RowIndex].ErrorText = "Некорректный символ!\nЗапрещено вводить символы: #, §, ~";
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // загрузка чека в табличу
        private void treeView_main_AfterSelect(object sender, TreeViewEventArgs e)
        {
            button_main_delete_check.Enabled = true; button_main_print_receipt.Enabled = true;
            try
            {
                TreeNode CurrentNode = treeView_main.SelectedNode;
                if (!File.Exists(FileNames[IndexFile]))
                {
                    DialogResult result = MessageBox.Show("Сохранить чек: \"" + Path.GetFileNameWithoutExtension(FileNames[IndexFile]).Replace("-", ":") + "\".", "Сохранить файл", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                        button_main_save_check_Click(this, null);
                    else
                        return;
                }

                if (CurrentNode != null)
                {
                    if (CurrentNode.Level == 0)
                    {
                        dataGridView_main.Rows.Clear();

                        IndexFile = CurrentNode.Index;
                        try
                        {
                            string input = File.ReadAllText(FileNames[CurrentNode.Index]);
                            string[] input_array = input.Split('\n');
                            dataGridView_main.Rows.Add(input_array.Length);
                            for (int i = 0; i < input_array.Length; i++)
                            {
                                string[] parts = input_array[i].Split(new char[] { '#', '§', '~' });
                                dataGridView_main.Rows[i].Cells[0].Value = parts[0];
                                dataGridView_main.Rows[i].Cells[1].Value = parts[1];
                                dataGridView_main.Rows[i].Cells[2].Value = parts[2];
                                dataGridView_main.Rows[i].Cells[3].Value = parts[3];
                            }
                        }
                        catch (FileNotFoundException) { FileNames.Remove(FileNames[CurrentNode.Index]); DrawTreeViewMain(); }
                        catch (ArgumentOutOfRangeException) { IndexFile = FileNames.Count - 1; DrawTreeViewMain(); }
                    }
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }

        // загрузка журнала в табличу
        private void treeView_log_AfterSelect(object sender, TreeViewEventArgs e)
        {
            button_log_delete_check.Enabled = true; button_log_print_receipt.Enabled = true;
            try
            {
                TreeNode CurrentNode = treeView_log.SelectedNode;
                if (CurrentNode != null)
                {
                    if (CurrentNode.Level == 1)
                    {
                        dataGridView_log.Rows.Clear();

                        string input = File.ReadAllText("Log/" + CurrentNode.Parent.Text + "/" + CurrentNode.Text.Replace(":", "-") + ".txt");
                        string[] input_array = input.Split('\n');
                        dataGridView_log.Rows.Add(input_array.Length);
                        for (int i = 0; i < input_array.Length; i++)
                        {
                            string[] parts = input_array[i].Split(new char[] { '#', '§', '~' });
                            dataGridView_log.Rows[i].Cells[0].Value = parts[0];
                            dataGridView_log.Rows[i].Cells[1].Value = parts[1];
                            dataGridView_log.Rows[i].Cells[2].Value = parts[2];
                            dataGridView_log.Rows[i].Cells[3].Value = parts[3];
                        }
                    }
                }
            }
            catch (Exception ee) { MessageBox.Show("Возникла ошибка при работе программы: " + ee.Message + "\nПричина: " + ee.Source + "\nВ методе: " + ee.TargetSite); }
        }
    }
}
